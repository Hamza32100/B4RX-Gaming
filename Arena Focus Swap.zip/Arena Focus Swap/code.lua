--Addon "Arena Focus Swap" created by Humerx (Humerx-Stormscale)

function afs()
print("|cff00ff00/click AFS1|r - If focus coincides with the current target or focus doesnt exists then focus is changing depending on the target.")
print([[Examples: 
-For 2x2 arena if target is arena1 then focus is changing to arena2. If target is arena2 then focus is changing to arena1
-For 3x3 arena if target is arena3 then focus is changing to arena2, but if arena2 is doesnt exists then focus is changing to arena1. etc.. 
]])
print("|cff00ff00/click AFS2|r - Macro for 3x3: swapping focus depending on the current focus and target.")
print([[Examples:
-If target is arena1 and focus is arena3 then focus is swapping to arena2.
-If target is arena2 and focus is arena1 then focus is swapping to arena3.
]])
end
----------------------------------------------------------------

soundafs=GetCVar("Sound_EnableSFX")

local sound=CreateFrame("Frame") sound:RegisterEvent("CVAR_UPDATE") 
sound:SetScript("OnEvent", function() soundafs=GetCVar("Sound_EnableSFX") end)

----------------------------------------------------------------

headerAE = CreateFrame("Frame", "AFSAE", nil, "SecureHandlerBaseTemplate")
buttonAE = CreateFrame("Button", "AFS01", nil, "SecureActionButtonTemplate")

buttonAE:SetAttribute("type", "actionbar")

PreClickSnippet = [==[
if UnitExists("arena1") and UnitExists("arena2") then
Page=GetActionBarPage() Page=Page+2 self:SetAttribute("action", Page) 
elseif UnitExists("arena1") and UnitExists("arena3") then Page=GetActionBarPage() Page=Page+2 self:SetAttribute("action", Page) 
elseif UnitExists("arena2") and UnitExists("arena3") then Page=GetActionBarPage() Page=Page+2 self:SetAttribute("action", Page) 
else Page=GetActionBarPage() self:SetAttribute("action", Page) 
end 
]==]


headerAE:WrapScript(buttonAE, "OnClick", PreClickSnippet)


----------------------------------------------------------------


headerTT = CreateFrame("Frame", "AFSTT", nil, "SecureHandlerBaseTemplate")
buttonTT = CreateFrame("Button", "AFS02", nil, "SecureActionButtonTemplate")

buttonTT:SetAttribute("type", "actionbar")

PreClickSnippet = [==[
TargetInParty=SecureCmdOptionParse("[@targettarget,party] 1; [@targettarget,noparty] 0")
FocusInParty=SecureCmdOptionParse("[@focustarget,party] 1; [@focustarget,noparty] 0")
if not(TargetInParty==FocusInParty) then
Page=GetActionBarPage() self:SetAttribute("action", Page)
elseif not(UnitExists("focustarget")==UnitExists("targettarget")) then Page=GetActionBarPage() self:SetAttribute("action", Page)
elseif not(PlayerCanAttack("focustarget")==PlayerCanAttack("targettarget")) then Page=GetActionBarPage() self:SetAttribute("action", Page) 
else Page=GetActionBarPage() Page=Page+2  self:SetAttribute("action", Page) 
end 
]==]


headerTT:WrapScript(buttonTT, "OnClick", PreClickSnippet)




----------------------------------------------------------------

text0=[[
/run SetCVar("Sound_EnableSFX", 0)
/click AFS1_1
/run SetCVar("Sound_EnableSFX", soundafs)
]]

text1=[[
/stopmacro [noexists]
/stopmacro [@arena1,help];[@arena2,help];[@arena3,help] 
/click AFS01
/click [actionbar:3/4] AFS02
/click [actionbar:3/4,@focus,noexists] AFS1_5
/click [actionbar:5/6] AFS1_5
/changeactionbar [actionbar:3/5] 1
/changeactionbar [actionbar:4/6] 2 
]]

text5=[[
/click  [@focus,noexists]AFS1_6
/stopmacro [@focus,noexists]
/target player
/targetlasttarget
/target focus
/targetlasttarget
/click [help]AFS1_6
]]

text6=[[
/target player
/targetlasttarget [@arena1,exists]
/target arena1
/targetlasttarget
/click [harm]AFS1_7
/stopmacro [harm]
/focus [@arena3,nodead,exists] 
/focus [@arena2,nodead,exists] 
/target  arena1
]]

text7=[[
/target player
/targetlasttarget [@arena2,exists]
/target arena2
/targetlasttarget
/click [harm]AFS1_8
/stopmacro [harm]
/focus [@arena3,nodead,exists] 
/focus [@arena1,nodead,exists]
/target  arena2
]]


text8=[[
/target player
/targetlasttarget [@arena3,exists]
/target arena3
/targetlasttarget
/stopmacro [harm]
/focus [@arena2,nodead,exists]
/focus [@arena1,nodead,exists]
/target arena3
]]

-----------------------------------------------------------
--AFS2

text09=[[
/run SetCVar("Sound_EnableSFX", 0)
/click AFS2_1
/run SetCVar("Sound_EnableSFX", soundafs)
]]

--AFS2_1

text9=[[
/stopmacro [@arena1,noexists]; [@arena2,noexists];[@arena3,noexists]
/changeactionbar [actionbar:1]3;[actionbar:2]4
/click AFS2_2
/changeactionbar [actionbar:3/5]1;[actionbar:4/6]2
]]

--AFS2_2

text10=[[
/target player
/targetlasttarget
/target arena1
/targetlasttarget
/click [harm] AFS2_3
/click [help] AFS2_4
]]

--AFS2_3

text11=[[
/target player
/targetlasttarget
/target arena2
/targetlasttarget
/click [harm]AFS2_5
/click [help]AFS2_6
]]

--AFS2_4

text12=[[
/target focus
/target arena2
/targetlasttarget
/focus [help] arena3
/focus [harm] arena2
/target arena1
]]

--AFS2_5

text13=[[
/target player
/target focus
/target arena2
/targetlasttarget
/focus [help] arena1
/focus [harm] arena2
/target arena3
]]

--AFS2_6

text14=[[
/target focus
/target arena1
/targetlasttarget
/focus [help]arena3
/focus [harm]arena1
/target arena2
]]

----------------------------------------------------------------

AFSq=CreateFrame("Button","AFS1", nil,"SecureActionButtonTemplate") 
AFSq:SetAttribute("type", "macro") 
AFSq:SetAttribute("macrotext", text0)

AFSq=CreateFrame("Button","AFS1_1", nil,"SecureActionButtonTemplate") 
AFSq:SetAttribute("type", "macro") 
AFSq:SetAttribute("macrotext", text1)


AFSw=CreateFrame("Button","AFS1_2", nil,"SecureActionButtonTemplate") 
AFSw:SetAttribute("type", "macro") 
AFSw:SetAttribute("macrotext", text2)

AFSe=CreateFrame("Button","AFS1_3", nil,"SecureActionButtonTemplate") 
AFSe:SetAttribute("type", "macro") 
AFSe:SetAttribute("macrotext", text3)

AFSr=CreateFrame("Button","AFS1_4", nil,"SecureActionButtonTemplate") 
AFSr:SetAttribute("type", "macro") 
AFSr:SetAttribute("macrotext", text4)

AFSt=CreateFrame("Button","AFS1_5", nil,"SecureActionButtonTemplate") 
AFSt:SetAttribute("type", "macro") 
AFSt:SetAttribute("macrotext", text5)

AFSy=CreateFrame("Button","AFS1_6", nil,"SecureActionButtonTemplate") 
AFSy:SetAttribute("type", "macro") 
AFSy:SetAttribute("macrotext", text6)

AFSu=CreateFrame("Button","AFS1_7", nil,"SecureActionButtonTemplate") 
AFSu:SetAttribute("type", "macro") 
AFSu:SetAttribute("macrotext", text7)

AFSi=CreateFrame("Button","AFS1_8", nil,"SecureActionButtonTemplate") 
AFSi:SetAttribute("type", "macro") 
AFSi:SetAttribute("macrotext", text8)

-------------------------------------------------------------


AFSa=CreateFrame("Button","AFS2", nil,"SecureActionButtonTemplate") 
AFSa:SetAttribute("type", "macro") 
AFSa:SetAttribute("macrotext", text09)

AFSa=CreateFrame("Button","AFS2_1", nil,"SecureActionButtonTemplate") 
AFSa:SetAttribute("type", "macro") 
AFSa:SetAttribute("macrotext", text9)

AFSs=CreateFrame("Button","AFS2_2", nil,"SecureActionButtonTemplate") 
AFSs:SetAttribute("type", "macro") 
AFSs:SetAttribute("macrotext", text10)


AFSd=CreateFrame("Button","AFS2_3", nil,"SecureActionButtonTemplate") 
AFSd:SetAttribute("type", "macro") 
AFSd:SetAttribute("macrotext", text11)


AFSf=CreateFrame("Button","AFS2_4", nil,"SecureActionButtonTemplate") 
AFSf:SetAttribute("type", "macro") 
AFSf:SetAttribute("macrotext", text12)


AFSg=CreateFrame("Button","AFS2_5", nil,"SecureActionButtonTemplate") 
AFSg:SetAttribute("type", "macro") 
AFSg:SetAttribute("macrotext", text13)


AFSh=CreateFrame("Button","AFS2_6", nil,"SecureActionButtonTemplate") 
AFSh:SetAttribute("type", "macro") 
AFSh:SetAttribute("macrotext", text14)




SLASH_AFS1 = "/afs"
SlashCmdList["AFS"] = afs 




	

